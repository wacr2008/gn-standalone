# How to update the [GN binaries](gn.md) that Chromium uses.

Any committer should be able to do a roll by running //tools/gn/bin/roll_gn.py
on linux or mac.
